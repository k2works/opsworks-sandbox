#
# Cookbook Name:: opsworks_cookbook_demo
# Recipe:: install_package
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
package "Install Emacs" do
  package_name "emacs"
end
