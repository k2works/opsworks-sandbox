#
# Cookbook Name:: opsworks_cookbook_demo
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
Chef::Log.info("********** Hello, World! **********")
