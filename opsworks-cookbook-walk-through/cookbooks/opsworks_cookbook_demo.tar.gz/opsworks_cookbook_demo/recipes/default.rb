#
# Cookbook Name:: opsworks_cookbook_demo
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
package "Install Emacs" do
  package_name "emacs"
end
