describe directory('/tmp/create-directory-demo') do
  it { should be_directory }
end
