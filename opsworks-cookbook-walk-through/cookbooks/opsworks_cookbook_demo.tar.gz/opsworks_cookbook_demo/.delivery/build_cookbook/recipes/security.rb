#
# Cookbook Name:: build_cookbook
# Recipe:: security
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
include_recipe 'delivery-truck::security'
